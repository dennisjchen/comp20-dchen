// Express initialization
var express = require('express');
var app = express.createServer(express.logger());
app.use(express.bodyParser());

// Mongo initialization
var mongoUri = 'mongodb://dchen01:ylyl105sucks@dharma.mongohq.com:10099/gamehub';
var mongo = require('mongodb');

app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.get('/', function(request, response, next) {
    response.send('<!DOCTYPE html><html><head><title>Scorecenter</title><script type="text/javascript" src="http://code.jquery.com/jquery-1.8.0.min.js"></script><script type="text/javascript">$(document).ready(function() {var scoreDiv = $("#scores").val();$.get("/scores.json", {}, function(results) {var div = $("#scores");div.html("");for(var i = 0; i < results.length; i++) {var score = results[i];div.append("<br/>Game: " + score.game_title + " | " + "User: " + score.username + " | " + " Score: " + score.score + " |  Created: " + score.created_at);}});});</script></head><body><h1>The Scores</h1><div id="scores"></div></body></html>');
});

app.get('/usersearch', function(request, response, next){
    response.send('<!DOCTYPE html><html><head><title>User Search</title><script type="text/javascript" src="http://code.jquery.com/jquery-1.8.0.min.js"></script><script type="text/javascript">$(document).ready(function() {$("#submit").click(function() {var user = $("#input").val();$.get("/scores.json", {username: user}, function(results) {var div = $("#scoresDiv");div.html("");div.append("<br/>User: " + user);var exists = false;for(var i = 0; i < results.length; i++) {var score = results[i];if(score.username == user){exists = true;div.append("<br/>Game: " + score.game_title + "    |    Score: " + score.score);}}if(!exists){div.append("<br/>User has no highscores");}});});});</script></head><body><h3>Username: </h3><input type="text"   id="input"></input><input type="submit" id="submit" value="Get Scores!"></button><div id="scoresDiv"></div></body></html>');
});

app.get('/scores.json', function(request, response, next){
    var db = mongo.Db.connect(mongoUri, function(er, client){
        var collection = new mongo.Collection(client, 'highscores');
        collection.find().toArray(function(err, results){
            response.send(results);
        });
    });
});

app.get('/highscores.json', function(request, response, next){
    gameName = request.query.game_title;
    if(gameName != null){
        var db = mongo.Db.connect(mongoUri, function(er, client){
            var collection = new mongo.Collection(client, 'highscores');
            collection.find({game_title : gameName}).sort({score:-1}).limit(10).toArray(function(err, results){
                response.send(results);
            });
        });
    }
    else{
        response.end("Please pass a game as argument");
    }
});

app.post('/submit.json', function(request, response) {
    aScore = request.body;
    var db = mongo.Db.connect(mongoUri, function(er, client){
        var collection = new mongo.Collection(client, 'highscores');
        if (aScore.game_title != null && aScore.username != null && aScore.score != null){
            var d = new Date();
            var theDate = d.toDateString() + ' ' + d.toTimeString();
            function isInt(n){return n%1 == 0};
            if (typeof Number(aScore.score) != "number"){
                response.send('ERROR: Argument for score must be an integer');
            }
            else if (!isInt(aScore.score)) { 
                response.stend('ERROR: Argument for score must be an integer');
            }
            else {
                collection.insert({'game_title':aScore.game_title, 'username':aScore.username, 'score':Number(aScore.score), 'created_at':theDate});
                response.send("Submission was successful!");
            }
        }
        else {
            response.send("Error in submitting. Please check parameters");
        }
    });
});

var port = process.env.PORT || 2139;
app.listen(port);