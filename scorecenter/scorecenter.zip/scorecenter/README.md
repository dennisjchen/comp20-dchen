Assignment 5: Scorecenter
1. All aspects have been implemented correctly
    -/submit.json
    -/highscores.json
    -/
    -/usersearch
    -.gitignore

2. Collaborated/Discuss with: Jim Mao, Amadou Crookes
3. Spent approximately 10 hours
4. README.md